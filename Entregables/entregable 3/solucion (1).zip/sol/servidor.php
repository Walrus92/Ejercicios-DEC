<?php

/*  Datos     */

class Alumno
{
    public $id;
    public $nombre;
    public $comentario;
}

$ids=0;

$alumno1 = new Alumno();
$alumno1->nombre="Laura Jiménez";

$alumno2 = new Alumno();
$alumno2->nombre="Pablo González";

$alumno3 = new Alumno();
$alumno3->nombre="Marta Domínguez";

$alumno4 = new Alumno();
$alumno4->nombre="María Antón";

$alumno5 = new Alumno();
$alumno5->nombre="José Luís Jiménez";

$alumno6 = new Alumno();
$alumno6->nombre="Antonio Lucas";

$alumnos=[$alumno1,$alumno2,$alumno3,$alumno4,$alumno5, $alumno6];


/*  Recepción de peticiones     */

if ($_REQUEST["opcion"] == "descargar"){
    echo json_encode($alumnos);
}


if ($_REQUEST["opcion"] == "actualiza"){
    $texto=$_REQUEST["nombre"]."\t\t".$_REQUEST["texto"]."\n";
    $fp = fopen("./documento.txt", "a");
    fwrite($fp,$texto);
    echo "Escribimos: ".$texto;
}

?>